## Telecom operators

Add support for unsupported operators so that Volte is already in normal use with NR

## Changelog
<br>https://github.com/ender-zhao/Pixel-5-NR-unlocked-by-Chinese-operators
<br> by Ender Zhao CLUB