SKIPMOUNT=false
PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false

  ui_print "Module installation is complete."
  ui_print "************************************"
  ui_print "             Pixel 5 "
  ui_print "           *NR Unlock* "
  ui_print "Thank you for choosing this module"
  ui_print "************************************"
  ui_print "Start deleting radio cache."
  ui_print "Start deleting /data/vendor/radio & /data/vendor/modem_fdr…"
  rm -r /data/vendor/radio && rm -r /data/vendor/modem_fdr
  ui_print "Execution complete!"
  ui_print "Start deleting /data/vendor/radio/iccid_0…"
  rm /data/vendor/radio/iccid_0
  ui_print "Execution complete!"
  ui_print "Start deleting /data/vendor/radio/qcril.db"
  rm /data/vendor/radio/qcril.db
  ui_print "Execution complete!"
  ui_print "Start deleting /data/vendor/radio/qcril_backup.db"
  rm /data/vendor/radio/qcril_backup.db
  ui_print "Execution complete!"
  ui_print "Start to complete the final debugging..."

REPLACE="
/vendor/rfs/msm/mpss/readonly/vendor/mbn/mcfg_sw
/system/vendor/rfs/msm/mpss/readonly/vendor/mbn/mcfg_sw
"

REPLACE="
"

on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  
  ui_print "- Parameter compiling"
  
  set_permissions() {
  set_perm_recursive  $MODPATH/system/vendor/mbn       0       0       0755            0644            u:object_r:vendor_file:s0

  set_perm_recursive  $MODPATH  0  0  0755  0644            u:object_r:vendor_file:s0
}

  ui_print "fully completed"
  ui_print "__________________________________"
  ui_print "you need to reboot."