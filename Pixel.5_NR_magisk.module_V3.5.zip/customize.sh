#!/system/bin/sh

  ui_print "************************************"
  ui_print " Pixel 5 "
  ui_print " NR Unlock "
  ui_print " CMCC stable，CT Unstable，CU Support volte! "
  rm -r /data/vendor/radio && rm -r /data/vendor/modem_fdr
  ui_print "************************************"